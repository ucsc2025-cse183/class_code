from py4web import action, redirect, HTTP, response, request

@action("test1")
def test1():    
    a = 1
    b = 2
    c = 3
    return locals()


@action("test2")
def test2():
    redirect("/demo1/test3")


@action("test3")
def test2():
    return "hello from test3"

